// CleanSpot minimal backend: Node.js built-in modules only (no npm install needed).
const http = require('http');
const fs = require('fs');
const path = require('path');
const ROOT = __dirname;
const DB = path.join(ROOT, 'reports.json');
const PORT = process.env.PORT || 3000;
const TYPES = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg' };
function readReports() { try { return JSON.parse(fs.readFileSync(DB, 'utf8')); } catch { return []; } }
function send(res, status, body, type='application/json; charset=utf-8') { res.writeHead(status, { 'Content-Type': type, 'Access-Control-Allow-Origin': '*' }); res.end(typeof body === 'string' ? body : JSON.stringify(body)); }
const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET,PUT,POST,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type' }); return res.end(); }
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/health') return send(res, 200, { ok:true, service:'CleanSpot API' });
  if (url.pathname === '/api/reports' && req.method === 'GET') return send(res, 200, readReports());
  if (url.pathname === '/api/reports' && (req.method === 'PUT' || req.method === 'POST')) {
    let raw = ''; req.on('data', chunk => { raw += chunk; if (raw.length > 12 * 1024 * 1024) { send(res, 413, { error:'Payload too large (12 MB limit)' }); req.destroy(); } });
    req.on('end', () => { try { const data = JSON.parse(raw || '[]'); if (!Array.isArray(data)) return send(res, 400, { error:'Expected an array of reports' }); fs.writeFileSync(DB, JSON.stringify(data, null, 2)); send(res, 200, { ok:true, count:data.length }); } catch { send(res, 400, { error:'Invalid JSON' }); } });
    return;
  }
  if (url.pathname.startsWith('/api/')) return send(res, 404, { error:'API route not found' });
  let filePath = path.join(ROOT, decodeURIComponent(url.pathname === '/' ? 'index.html' : url.pathname));
  if (!filePath.startsWith(ROOT)) return send(res, 403, 'Forbidden', 'text/plain');
  fs.readFile(filePath, (err, data) => { if (err) return send(res, 404, 'Not found. Open http://localhost:3000', 'text/plain; charset=utf-8'); res.writeHead(200, { 'Content-Type': TYPES[path.extname(filePath)] || 'application/octet-stream' }); res.end(data); });
});
server.listen(PORT, '0.0.0.0', () => console.log(`CleanSpot running at http://localhost:${PORT}`));
