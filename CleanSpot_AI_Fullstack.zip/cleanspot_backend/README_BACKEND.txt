CLEANSPOT AI — BACKEND QUICK START

What is included:
- server.js: Node.js backend + static web server + JSON API
- reports.json: created automatically when reports are saved
- index.html, style.css, script.js: frontend

RUN IT (internet not needed for backend itself):
1. Install Node.js LTS if not already installed: https://nodejs.org/
2. Extract this ZIP to a folder.
3. Open that folder in VS Code.
4. In VS Code: Terminal > New Terminal.
5. Run: node server.js
6. Open: http://localhost:3000
7. To check backend: open http://localhost:3000/api/health

No npm install is needed; the backend uses Node.js built-in modules only.
Reports are stored in reports.json and shared by browsers that connect to this same running server. For other people to access it, deploy the server to a public host. This is a student prototype: no login, permissions, production security, or cloud database is included. Do not put real personal or sensitive data in it.

AI note: the photo detection model loads from external CDN/model hosting and needs internet access. Predictions can be wrong.
