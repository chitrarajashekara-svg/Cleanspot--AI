const STORAGE_KEY = "cleanspot_reports_v2";
const CATEGORIES = [
  "Plastic Waste", "Food Waste", "Mixed Garbage",
  "Construction Waste", "Electronic Waste", "Other"
];
const STATUSES = ["Pending Review", "Under Follow-up", "Cleaned (Demo)"];

// These are explicitly marked as sample/demo entries for presentation.
const DEMO_REPORTS = [
  { id: "DEMO-101", location: "College Main Gate", category: "Plastic Waste", severity: "Moderate amount", description: "Sample entry: disposable cups and wrappers reported near the public entrance.", status: "Pending Review", createdAt: "2026-10-15T09:00:00", demo: true },
  { id: "DEMO-102", location: "College Main Gate", category: "Mixed Garbage", severity: "Large amount", description: "Sample entry: mixed waste bags beside the community bin.", status: "Under Follow-up", createdAt: "2026-10-15T11:30:00", demo: true },
  { id: "DEMO-103", location: "City Bus Stop", category: "Food Waste", severity: "Small amount", description: "Sample entry: food packaging and disposable plates around the stop.", status: "Pending Review", createdAt: "2026-10-14T15:10:00", demo: true },
  { id: "DEMO-104", location: "Lake Walking Path", category: "Plastic Waste", severity: "Moderate amount", description: "Sample entry: plastic bottles noticed beside a public walking path.", status: "Pending Review", createdAt: "2026-10-13T08:20:00", demo: true },
  { id: "DEMO-105", location: "College Main Gate", category: "Plastic Waste", severity: "Small amount", description: "Sample entry: another report for the same location to demonstrate hotspot grouping.", status: "Pending Review", createdAt: "2026-10-16T08:15:00", demo: true },
  { id: "DEMO-106", location: "Market Street Corner", category: "Construction Waste", severity: "Not sure", description: "Sample entry: loose construction material visible at the edge of a public footpath.", status: "Cleaned (Demo)", createdAt: "2026-10-12T13:45:00", demo: true }
];

let reports = loadReports();
let selectedPhotoData = "";

const form = document.getElementById("reportForm");
const formMessage = document.getElementById("formMessage");
const photoInput = document.getElementById("photo");
const photoPreview = document.getElementById("photoPreview");
const analyzePhotoBtn = document.getElementById("analyzePhotoBtn");
const aiStatus = document.getElementById("aiStatus");
const aiResults = document.getElementById("aiResults");
let aiModelPromise = null;
let aiSuggestedCategory = "";

function loadReports() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === null) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_REPORTS));
      return [...DEMO_REPORTS];
    }
    const parsed = JSON.parse(saved);
    if (!Array.isArray(parsed)) throw new Error("Saved report data is invalid");
    return parsed;
  } catch (error) {
    console.error("CleanSpot could not load saved reports:", error);
    return [...DEMO_REPORTS];
  }
}

function saveReports() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    // When launched through server.js, sync reports to the shared backend.
    fetch("/api/reports", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(reports)
    }).catch(() => console.warn("Backend unavailable; reports remain in this browser."));
    return true;
  } catch (error) {
    console.error("CleanSpot could not save reports:", error);
    return false;
  }
}

function normaliseLocation(value) {
  return value.trim().toLocaleLowerCase().replace(/\s+/g, " ");
}

function countLocations() {
  const grouped = new Map();
  reports.forEach(report => {
    const key = normaliseLocation(report.location || "");
    if (!key) return;
    if (!grouped.has(key)) grouped.set(key, { name: (report.location || "").trim(), count: 0, categories: new Set(), pending: 0 });
    const item = grouped.get(key);
    item.count++;
    item.categories.add(report.category);
    if (report.status !== "Cleaned (Demo)") item.pending++;
  });
  return [...grouped.values()].sort((a, b) => b.count - a.count);
}

function updateDashboard() {
  document.getElementById("totalReports").textContent = reports.length;
  document.getElementById("pendingReports").textContent =
    reports.filter(r => r.status === "Pending Review" || r.status === "Under Follow-up").length;
  const hotspots = countLocations().filter(item => item.count >= 2);
  document.getElementById("totalHotspots").textContent = hotspots.length;
  document.getElementById("focusNumber").innerHTML = `${hotspots.length} <small>locations</small>`;
  document.getElementById("focusDescription").textContent = hotspots.length
    ? `${hotspots[0].name} currently has the most repeated reports (${hotspots[0].count}). This is a signal for follow-up, not a verified cleanliness rating.`
    : "Repeated reports will appear here as patterns emerge.";

  const counts = Object.fromEntries(CATEGORIES.map(category => [category, 0]));
  reports.forEach(report => {
    if (Object.prototype.hasOwnProperty.call(counts, report.category)) counts[report.category]++;
  });
  const top = CATEGORIES.map(category => ({ category, count: counts[category] }))
    .sort((a, b) => b.count - a.count)[0];
  document.getElementById("topCategory").textContent = top && top.count ? top.category : "—";
  renderCategoryChart(counts);
}

function renderCategoryChart(counts) {
  const chart = document.getElementById("categoryChart");
  chart.replaceChildren();
  const maxCount = Math.max(1, ...Object.values(counts));
  CATEGORIES.forEach(category => {
    const row = document.createElement("div");
    row.className = "chart-row";
    const name = document.createElement("span");
    name.className = "chart-name";
    name.textContent = category;
    const track = document.createElement("div");
    track.className = "bar-track";
    track.setAttribute("role", "img");
    track.setAttribute("aria-label", `${category}: ${counts[category]} reports`);
    const fill = document.createElement("div");
    fill.className = "bar-fill";
    fill.style.width = `${counts[category] / maxCount * 100}%`;
    track.appendChild(fill);
    const count = document.createElement("span");
    count.className = "chart-count";
    count.textContent = counts[category];
    row.append(name, track, count);
    chart.appendChild(row);
  });
}

function makeStatusChip(status) {
  const chip = document.createElement("span");
  chip.className = "status-chip";
  if (status === "Under Follow-up") chip.classList.add("followup");
  if (status === "Cleaned (Demo)") chip.classList.add("cleaned");
  chip.textContent = status;
  return chip;
}

function renderReports() {
  const container = document.getElementById("reportsList");
  const search = document.getElementById("searchInput").value.trim().toLowerCase();
  const category = document.getElementById("filterCategory").value;
  const status = document.getElementById("filterStatus").value;

  const filtered = reports.filter(report => {
    const haystack = `${report.location} ${report.description} ${report.category}`.toLowerCase();
    return (!search || haystack.includes(search))
      && (!category || report.category === category)
      && (!status || report.status === status);
  }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  document.getElementById("resultCount").textContent = `${filtered.length} ${filtered.length === 1 ? "report" : "reports"}`;
  container.replaceChildren();

  if (!filtered.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    const title = document.createElement("strong");
    title.textContent = "No matching reports";
    const text = document.createElement("span");
    text.textContent = "Try another search or clear one of the filters.";
    empty.append(title, text);
    container.appendChild(empty);
    return;
  }

  filtered.forEach(report => {
    const card = document.createElement("article");
    card.className = "report-card";
    const top = document.createElement("div");
    top.className = "card-topline";
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = report.category;
    const id = document.createElement("span");
    id.className = "report-id";
    id.textContent = report.demo ? "SAMPLE" : `#${String(report.id).slice(-6)}`;
    top.append(badge, id);

    const heading = document.createElement("h3");
    heading.textContent = `⌖ ${report.location}`;
    const description = document.createElement("p");
    description.className = "description";
    description.textContent = report.description;
    const meta = document.createElement("div");
    meta.className = "report-meta";
    const date = document.createElement("span");
    date.textContent = `◷ ${formatDate(report.createdAt)}`;
    const severity = document.createElement("span");
    severity.textContent = `• ${report.severity || "Amount not specified"}`;
    meta.append(date, severity);
    card.append(top, heading, description, meta);

    if (report.photoData) {
      const img = document.createElement("img");
      img.src = report.photoData;
      img.alt = "Photo attached to this report";
      img.loading = "lazy";
      img.style.cssText = "display:block;max-width:100%;max-height:170px;object-fit:contain;border-radius:9px;margin-top:12px;";
      card.appendChild(img);
    }

    card.appendChild(makeStatusChip(report.status));
    const statusSelect = document.createElement("select");
    statusSelect.className = "status-select";
    statusSelect.setAttribute("aria-label", `Update status for ${report.location}`);
    STATUSES.forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = `Set status: ${value}`;
      option.selected = value === report.status;
      statusSelect.appendChild(option);
    });
    statusSelect.addEventListener("change", () => updateReportStatus(report.id, statusSelect.value));
    card.appendChild(statusSelect);
    if (report.demo) {
      const sampleNote = document.createElement("p");
      sampleNote.style.cssText = "margin-top:9px;color:#9aa69f;font-size:9px;";
      sampleNote.textContent = "Illustrative sample data";
      card.appendChild(sampleNote);
    }
    container.appendChild(card);
  });
}

function updateReportStatus(id, newStatus) {
  const index = reports.findIndex(report => String(report.id) === String(id));
  if (index === -1 || !STATUSES.includes(newStatus)) return;
  const oldStatus = reports[index].status;
  reports[index].status = newStatus;
  if (!saveReports()) {
    reports[index].status = oldStatus;
    showMessage("Could not save the status. Browser storage may be full.", true);
    renderReports();
    return;
  }
  renderAll();
}

function renderHotspots() {
  const container = document.getElementById("hotspotsList");
  const hotspots = countLocations().filter(item => item.count >= 2);
  container.replaceChildren();

  if (!hotspots.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    const title = document.createElement("strong");
    title.textContent = "No repeated hotspots yet";
    const body = document.createElement("span");
    body.textContent = "When the same location is reported at least twice, it will appear here.";
    empty.append(title, body);
    container.appendChild(empty);
    return;
  }

  hotspots.forEach((hotspot, index) => {
    const card = document.createElement("article");
    card.className = "hotspot-card";
    const info = document.createElement("div");
    const title = document.createElement("h3");
    title.textContent = `${index === 0 ? "🔥 " : "📍 "}${hotspot.name}`;
    const description = document.createElement("p");
    description.textContent = `${hotspot.categories.size} waste type${hotspot.categories.size === 1 ? "" : "s"} reported at this location.`;
    const sub = document.createElement("p");
    sub.className = "hotspot-sub";
    sub.textContent = `${hotspot.pending} report${hotspot.pending === 1 ? "" : "s"} still need follow-up`;
    info.append(title, description, sub);
    const count = document.createElement("span");
    count.className = "hotspot-count";
    count.textContent = `${hotspot.count} reports`;
    card.append(info, count);
    container.appendChild(card);
  });
}

function formatDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Date unavailable";
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function showMessage(message, isError = false) {
  formMessage.textContent = message;
  formMessage.classList.toggle("error", isError);
}

function renderAll() {
  updateDashboard();
  renderReports();
  renderHotspots();
}

photoInput.addEventListener("change", () => {
  selectedPhotoData = "";
  aiSuggestedCategory = "";
  aiResults.replaceChildren();
  aiResults.hidden = true;
  aiStatus.textContent = "Photo selected. Press Analyse photo with AI to run object detection.";
  aiStatus.classList.remove("error");
  photoPreview.replaceChildren();
  photoPreview.hidden = true;
  const file = photoInput.files && photoInput.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showMessage("Please select an image file.", true);
    photoInput.value = "";
    return;
  }
  if (file.size > 1.5 * 1024 * 1024) {
    showMessage("Please choose an image smaller than 1.5 MB for this browser demo.", true);
    photoInput.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    selectedPhotoData = String(reader.result || "");
    const img = document.createElement("img");
    img.src = selectedPhotoData;
    img.alt = "Selected photo preview";
    photoPreview.appendChild(img);
    photoPreview.hidden = false;
  };
  reader.onerror = () => showMessage("Could not read that image. Try another one.", true);
  reader.readAsDataURL(file);
});

// Genuine in-browser AI object detection using the pretrained COCO-SSD model.
// It detects common objects (for example bottle/cup/banana), not whether an object is litter.
function setAIStatus(message, isError = false) {
  aiStatus.textContent = message;
  aiStatus.classList.toggle("error", isError);
}

function loadAIModel() {
  if (aiModelPromise) return aiModelPromise;
  aiModelPromise = new Promise((resolve, reject) => {
    if (typeof tf === "undefined" || typeof cocoSsd === "undefined") {
      reject(new Error("AI libraries could not load. Check your internet connection and refresh the page."));
      return;
    }
    setAIStatus("Loading the AI model for the first time. With slow internet this may take a little while…");
    cocoSsd.load({ base: "lite_mobilenet_v2" }).then(resolve).catch(reject);
  }).catch(error => {
    aiModelPromise = null;
    throw error;
  });
  return aiModelPromise;
}

function suggestWasteCategory(predictions) {
  const labels = predictions.map(item => item.class.toLowerCase());
  if (labels.some(label => ["banana", "apple", "orange", "broccoli", "carrot", "sandwich", "pizza", "donut", "cake"].includes(label))) return "Food Waste";
  if (labels.some(label => ["bottle", "cup", "wine glass"].includes(label))) return "Plastic Waste";
  return "";
}

analyzePhotoBtn.addEventListener("click", async () => {
  const file = photoInput.files && photoInput.files[0];
  if (!file || !selectedPhotoData) {
    setAIStatus("Please choose a photo above before running AI analysis.", true);
    return;
  }
  if (!file.type.startsWith("image/")) {
    setAIStatus("Please select a valid image file.", true);
    return;
  }

  analyzePhotoBtn.disabled = true;
  analyzePhotoBtn.textContent = "Analysing photo…";
  aiResults.hidden = true;
  aiSuggestedCategory = "";
  try {
    const model = await loadAIModel();
    const image = new Image();
    image.src = selectedPhotoData;
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error("The selected photo could not be opened."));
    });
    setAIStatus("AI is analysing visible objects in your photo…");
    const predictions = await model.detect(image, 10, 0.35);
    aiResults.replaceChildren();

    if (!predictions.length) {
      aiResults.textContent = "The model did not confidently recognise any supported objects. Try a clearer photo with objects visible.";
      aiResults.hidden = false;
      setAIStatus("Analysis complete. No supported objects were detected.");
      return;
    }

    const title = document.createElement("strong");
    title.textContent = "AI-detected objects";
    aiResults.appendChild(title);
    const list = document.createElement("ul");
    list.style.margin = "6px 0 0";
    list.style.paddingLeft = "19px";
    predictions.slice(0, 5).forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.class} — ${Math.round(item.score * 100)}% model confidence`;
      list.appendChild(li);
    });
    aiResults.appendChild(list);

    aiSuggestedCategory = suggestWasteCategory(predictions);
    if (aiSuggestedCategory) {
      const suggestion = document.createElement("p");
      suggestion.style.margin = "8px 0 0";
      suggestion.textContent = `Possible category suggestion: ${aiSuggestedCategory}. This is only a suggestion—please verify it.`;
      aiResults.appendChild(suggestion);
      document.getElementById("category").value = aiSuggestedCategory;
    } else {
      const note = document.createElement("p");
      note.style.margin = "8px 0 0";
      note.textContent = "No direct waste-category suggestion was made. Please choose the category yourself.";
      aiResults.appendChild(note);
    }
    aiResults.hidden = false;
    setAIStatus("Analysis complete. Predictions are generated by a pretrained AI model and may be inaccurate.");
  } catch (error) {
    console.error("CleanSpot AI analysis failed:", error);
    setAIStatus(error.message || "AI analysis failed. Check your connection and try again.", true);
  } finally {
    analyzePhotoBtn.disabled = false;
    analyzePhotoBtn.textContent = "✦ Analyse photo with AI";
  }
});

form.addEventListener("submit", event => {
  event.preventDefault();
  const location = document.getElementById("location").value.trim();
  const category = document.getElementById("category").value;
  const severity = document.getElementById("severity").value;
  const description = document.getElementById("description").value.trim();

  if (!location || !category || !description) {
    showMessage("Please complete the required fields.", true);
    return;
  }

  const newReport = {
    id: `USER-${Date.now()}`,
    location,
    category,
    severity,
    description,
    status: "Pending Review",
    createdAt: new Date().toISOString(),
    demo: false
  };
  if (selectedPhotoData) newReport.photoData = selectedPhotoData;

  reports.unshift(newReport);
  if (!saveReports()) {
    reports.shift();
    showMessage("Unable to save this report. Try a smaller photo or remove the photo and submit again.", true);
    return;
  }

  form.reset();
  selectedPhotoData = "";
  photoPreview.replaceChildren();
  photoPreview.hidden = true;
  showMessage("Report saved in this browser demo. It has not been sent to an authority.");
  renderAll();
  document.getElementById("reports").scrollIntoView({ behavior: "smooth", block: "start" });
});

["searchInput", "filterCategory", "filterStatus"].forEach(id => {
  const element = document.getElementById(id);
  element.addEventListener(id === "searchInput" ? "input" : "change", renderReports);
});

// If served by the included backend, load shared reports first. Otherwise use local demo storage.
fetch("/api/reports")
  .then(response => { if (!response.ok) throw new Error("Backend unavailable"); return response.json(); })
  .then(serverReports => {
    if (Array.isArray(serverReports) && serverReports.length) {
      reports = serverReports;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } else {
      // Seed the backend with the current demo/sample reports on first run.
      saveReports();
    }
    renderAll();
  })
  .catch(() => renderAll());
